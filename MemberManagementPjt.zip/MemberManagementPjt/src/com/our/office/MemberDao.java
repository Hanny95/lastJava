package com.our.office;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;





public class MemberDao {
	
	
	private final String driver = "org.mariadb.jdbc.Driver";
	private final String url = "jdbc:mariadb://localhost:3306/memberdb";
	private final String userID = "root";
	private final String userPW = "1234";
	
	
	public int insert(MemberVo memberVo) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		
		try {
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url, userID, userPW);
			
			String sql = "INSERT INTO tbl_members(m_name, m_mail, m_address, m_phone, m_reg_date, m_mod_date) VALUES(?, ?, ?, ?, NOW(), NOW())";
			pstmt = conn.prepareStatement(sql);
	
			pstmt.setString(1, memberVo.getM_name());
			pstmt.setString(2, memberVo.getM_mail());
			pstmt.setString(3, memberVo.getM_address());
			pstmt.setString(4, memberVo.getM_phone());
			
			result = pstmt.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
			
		} finally {
			try {
				
				if (pstmt != null) pstmt.close();
				if (conn != null) conn.close();
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return result;

	}


	public ArrayList<MemberVo> select() {
		
		Connection conn = null;
		PreparedStatement pstmt = null;   				//일꾼
		ResultSet rs = null;                          // 데이터를 가져와야함 (데이터베이스 자료를 그대로 가져옴)
		
		// 데이터를 배열에 담기
		ArrayList<MemberVo> memberVos = new ArrayList<MemberVo>();
		
		// DB를 연결해줄 프로그램 
		
		try {
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url, userID, userPW);
			
			String sql = "SELECT * FROM tbl_members";
			pstmt = conn.prepareStatement(sql);
		
			// 데이터를 가져올때는 executeQuery , 반환형은 ResultSet
			rs = pstmt.executeQuery();
			// 데이터를 자바형식으로 바꿈  next의 반환형은 boolean (다음에 읽을 데이터가 있으면 true 없으면 false 더이상 읽을것이 없으면 반복문 중단)
			while (rs.next()) {
				int m_no = rs.getInt("m_no");
				String m_name = rs.getString("m_name");
				String m_mail = rs.getString("m_mail");
				String m_address = rs.getString("m_address");
				String m_phone = rs.getString("m_phone");
				String m_reg_date = rs.getString("m_reg_date");
				String m_mod_date = rs.getString("m_mod_date");
				
				
				// 생성자 이용 방법 (MemberVo에 오버로딩)
				MemberVo memberVo = new MemberVo(m_no, m_name, m_mail, m_address, m_phone, m_reg_date, m_mod_date);

				
				// 데이터를 배열에 담기
				memberVos.add(memberVo);
				

			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
		} finally {
			try {
				
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (conn != null) conn.close();
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		// ArrayList 반환
		return memberVos;
	}


	public MemberVo getMemberVo(int mNo) {
		
	
		Connection conn = null;
		PreparedStatement pstmt = null;   				//일꾼
		ResultSet rs = null;                          // 데이터를 가져와야함 (데이터베이스 자료를 그대로 가져옴)
		
		// 데이터를 배열에 담기
		ArrayList<MemberVo> memberVos = new ArrayList<MemberVo>();
		
		// DB를 연결해줄 프로그램 
		
		try {
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url, userID, userPW);
			
			String sql = "SELECT * FROM tbl_members WHERE m_no =" + mNo;
			pstmt = conn.prepareStatement(sql);
		
			// 데이터를 가져올때는 executeQuery , 반환형은 ResultSet
			rs = pstmt.executeQuery();
			// 데이터를 자바형식으로 바꿈  next의 반환형은 boolean (다음에 읽을 데이터가 있으면 true 없으면 false 더이상 읽을것이 없으면 반복문 중단)
			while (rs.next()) {
				int m_no = rs.getInt("m_no");
				String m_name = rs.getString("m_name");
				String m_mail = rs.getString("m_mail");
				String m_address = rs.getString("m_address");
				String m_phone = rs.getString("m_phone");
				String m_reg_date = rs.getString("m_reg_date");
				String m_mod_date = rs.getString("m_mod_date");
				
				MemberVo memberVo = new MemberVo();
				memberVo.setM_no(m_no);
				memberVo.setM_name(m_name);
				memberVo.setM_mail(m_mail);
				memberVo.setM_address(m_address);
				memberVo.setM_phone(m_phone);
				memberVo.setM_reg_date(m_reg_date);
				memberVo.setM_mod_date(m_mod_date);
				
				// 데이터를 배열에 담기
				memberVos.add(memberVo);
				

			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
		} finally {
			try {
				
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (conn != null) conn.close();
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		
		if (memberVos.get(0) != null) {
			return memberVos.get(0);
		} else {
			return null;
	}
	
	}


	


	


	public int update(MemberVo memberVo) {
		
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		
		
		try {
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url, userID, userPW);
			
			String sql = "UPDATE tbl_members SET m_name = ?, m_mail = ?, m_address = ?, m_phone = ? WHERE m_no = ?";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, memberVo.getM_name());
			pstmt.setString(2, memberVo.getM_mail());
			pstmt.setString(3, memberVo.getM_address());
			pstmt.setString(4, memberVo.getM_phone());
			pstmt.setInt(5, memberVo.getM_no());
		
			result = pstmt.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
			
		} finally {
			try {
				
				if (pstmt != null) pstmt.close();
				if (conn != null) conn.close();
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return result;
		
	}


	public int delete(int m_no) {
		
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		
		try {
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url, userID, userPW);
			
			if (conn == null) {
				System.out.println("MARIADB CONNECTTION ERROR!");
			}
		
			String sql = "DELETE FROM tbl_members WHERE m_no = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, m_no);
			
			result = pstmt.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
			
		} finally {
			try {
				
				if (pstmt != null) pstmt.close();
				if (conn != null) conn.close();
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return result;
	}
}
