package com.our.office;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MemberService {
	
	// 멤버 Dao 생성
	MemberDao memberDao = new MemberDao();
	
	

	public void registerConfirm(HttpServletRequest request, HttpServletResponse response) {
		
		
		String m_name = request.getParameter("m_name");
		String m_mail = request.getParameter("m_mail");
		String m_address = request.getParameter("m_address");
		String m_phone = request.getParameter("m_phone");
		
		int result = memberDao.insert(new MemberVo(m_name, m_mail, m_address, m_phone));
		
		String resultStr = (result == 1) ? "SUCCESS" : "FAIL";
		System.out.println("ADD NEW MEMBER" + resultStr);
		
		
	}

	public void getList(HttpServletRequest request, HttpServletResponse response) {
		
		ArrayList<MemberVo> memberVos = memberDao.select();
		request.setAttribute("memberVos", memberVos);
		
	}

	public void modify(HttpServletRequest request, HttpServletResponse response) {
		
		int m_no = Integer.parseInt(request.getParameter("m_no"));
		
		MemberVo memberVo = memberDao.getMemberVo(m_no);
		request.setAttribute("memberVo", memberVo);
		
		
	}

	public void modifyConfirm(HttpServletRequest request, HttpServletResponse response) {
		
		int m_no = Integer.parseInt(request.getParameter("m_no"));
		
		String m_name = request.getParameter("m_name");
		String m_mail = request.getParameter("m_mail");
		String m_address = request.getParameter("m_address");
		String m_phone = request.getParameter("m_phone");
		
		int result = memberDao.update(new MemberVo(m_no, m_name, m_mail, m_address, m_phone));
		
		if (result > 0) {
			System.out.println("UPDATE SUCCESS");
		} else {
			System.out.println("UPDATE FAIL");
		}
		
	}

	public void delete(HttpServletRequest request, HttpServletResponse response) {
		
		int m_no = Integer.parseInt(request.getParameter("m_no"));
		
		int result = memberDao.delete(m_no);
		
		if (result > 0) {
			System.out.println("DELETE SUCCESS");
		} else {
			System.out.println("DELETE FAIL");
		}
		
	}

	

	
	
	
}
