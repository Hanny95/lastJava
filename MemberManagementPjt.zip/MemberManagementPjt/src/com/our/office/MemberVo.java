package com.our.office;

public class MemberVo {

	private int m_no;
	private String m_name;
	private String m_mail;
	private String m_address;
	private String m_phone;
	private String m_reg_date;
	private String m_mod_date;
	
	public MemberVo() {
		
	}
	
	public MemberVo(String m_name, String m_mail, String m_address, String m_phone) {
		
		
		this.m_name = m_name;
		this.m_mail = m_mail;
		this.m_address = m_address;
		this.m_phone = m_phone;
		
	}
	
	public MemberVo(int m_no, String m_name, String m_mail, String m_address, String m_phone) {
		
		this.m_no = m_no;
		this.m_name = m_name;
		this.m_mail = m_mail;
		this.m_address = m_address;
		this.m_phone = m_phone;
		
	}
	
	public MemberVo(int m_no, String m_name, String m_mail, String m_address, String m_phone, String m_reg_date, String m_mod_date) {
		
		this.m_no = m_no;
		this.m_name = m_name;
		this.m_mail = m_mail;
		this.m_address = m_address;
		this.m_phone = m_phone;
		this.m_reg_date = m_reg_date;
		this.m_mod_date = m_mod_date;
		
	}
	

	
	public int getM_no() {
		return m_no;
	}
	public void setM_no(int m_no) {
		this.m_no = m_no;
	}
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
	public String getM_mail() {
		return m_mail;
	}
	public void setM_mail(String m_mail) {
		this.m_mail = m_mail;
	}
	public String getM_address() {
		return m_address;
	}
	public void setM_address(String m_address) {
		this.m_address = m_address;
	}
	public String getM_phone() {
		return m_phone;
	}
	public void setM_phone(String m_phone) {
		this.m_phone = m_phone;
	}
	public String getM_reg_date() {
		return m_reg_date;
	}
	public void setM_reg_date(String m_reg_date) {
		this.m_reg_date = m_reg_date;
	}
	public String getM_mod_date() {
		return m_mod_date;
	}
	public void setM_mod_date(String m_mod_date) {
		this.m_mod_date = m_mod_date;
	}
	
	
	
	
	
}
