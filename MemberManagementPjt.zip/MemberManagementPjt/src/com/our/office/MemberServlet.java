package com.our.office;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MemberServlet
 */
@WebServlet("*.do")
public class MemberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MemberServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String requestURL = request.getRequestURL().toString();
		String requestURI = request.getRequestURI(); 
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length()); 
		
		
		MemberService memberService = null;
		
		String nextPage = null;     // 다음 페이지 
		
		
		// 멤버 등록
		if (command.equals("/register.do")) {
			
			nextPage = "register.jsp";
			
		// 멤버 등록 확인
		} else if  (command.equals("/registerConfirm.do")) {
			
			memberService = new MemberService();
			memberService.registerConfirm(request, response);
			nextPage = "list.do";
			
		// 멤버 리스트 	
		} else if  (command.equals("/list.do")) {
			
			memberService = new MemberService();
			memberService.getList(request, response);
			nextPage = "list.jsp";
			
		// 멤버 수정
		} else if  (command.equals("/modify.do")) {
			
			memberService = new MemberService();
			memberService.modify(request, response);
			nextPage = "modify.jsp";
			
		// 멤버 수정 확인
		}  else if  (command.equals("/modifyConfirm.do")) {
			
			memberService = new MemberService();
			memberService.modifyConfirm(request, response);
			nextPage = "list.do";
			
		// 멤버 삭제
		}  else if  (command.equals("/delete.do")) {
			
			memberService = new MemberService();
			memberService.delete(request, response);
			nextPage = "/list.do";
		}
		 
		
		RequestDispatcher requestDispatcher = request.getRequestDispatcher(nextPage);
		requestDispatcher.forward(request, response);
		
		
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		doGet(request, response);
	}

}
