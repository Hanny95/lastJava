function addFun() {
	
	var register_form = document.registerForm;
	
	
	if(register_form.s_name.value=="") {
		alert('이름을 입력하세요');
		register_form.s_name.focus();
		
	} else if(register_form.s_gender.value=="") {
		alert('성별을 선택하세요');
		register_form.s_gender.focus();
		
	} else if(register_form.s_grade.value=="") {
		alert('학년을 선택하세요');
		register_form.s_grade.focus();
		
	} else if(register_form.s_number.value=="") {
		alert('번호를 입력하세요');
		register_form.s_number.focus();
		
	} else if(register_form.s_major.value=="") {
		alert('전공을 선택하세요');
		register_form.s_major.focus();
		
	} else if(register_form.s_phone.value=="") {
		alert('연락처를 입력하세요');
		register_form.s_phone.focus();
		
	} else if(register_form.s_mail.value=="") {
		alert('메일을 입력하세요');
		register_form.s_mail.focus();
	
	/*	
	} else if(register_form.s_hobby.value=="") {
		alert('취미를 선택하세요');
		
	
	 hobbyChecked = function(){
    for(var i = 0; i < document.getElementsById('hobby').length; i++){
        if(document.getElementsById('hobby')[i].getAttribute('type') == 'checkbox'){
            document.getElementsById('hobby')[i].checked = true;
        }
    }
};
*/	
	

	} else if(register_form.s_absence.value=="") {
		alert('휴학을 선택하세요');
		register_form.s_absence.focus();
		
	}  else {
		
		var hobbys = register.form.s_hobby;
		var minChecked = 2;
		var curChecked = 0;
		
		for(var i = 0; i < hobbys.length; i++) {
			console.log(hobby[i].checked)
			curChecked++;
		}
	};


	if(curChecked > minChecked) {
		register_form.submit();
	} else {
		alert("취미는 최소 2개이상 선택해야 합니다.")
	}
	
}