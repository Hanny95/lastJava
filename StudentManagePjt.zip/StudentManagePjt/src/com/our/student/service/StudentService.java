package com.our.student.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.our.student.dao.StudentDao;
import com.our.student.vo.StudentVo;



public class StudentService {

	
	StudentDao studentDao = new StudentDao();
	
	
	public void addStudent(HttpServletRequest request, HttpServletResponse response) {
		
		String s_name = request.getParameter("s_name");
		String s_gender = request.getParameter("s_gender");
		int s_grade = Integer.parseInt(request.getParameter("s_grade"));
		int s_number = Integer.parseInt(request.getParameter("s_number"));
		String s_major = request.getParameter("s_major");
		String s_phone = request.getParameter("s_phone");
		String s_mail = request.getParameter("s_mail");
		
		String s_absence = request.getParameter("s_absence");
		String s_reg_date = request.getParameter("s_reg_date");
		String s_mod_date = request.getParameter("s_mod_date");
		
		String s_hobby = "";
		String[] s_hobbys = request.getParameterValues("s_hobby");
		
		for (int i = 0; i < s_hobbys.length; i++) {
			if (i != s_hobbys.length -1 ) {
			s_hobby += s_hobbys[i] + ','; 
			} else {
			s_hobby += s_hobbys[i];
			}
			
			
		}
		
		
		int result = studentDao.insertStudent(new StudentVo(s_name, s_gender, s_grade, s_number, s_major, s_phone, s_mail, s_hobby, s_absence, s_reg_date, s_mod_date));
		
		if (result > 0) 
			System.out.println("INSERT SUCCESS");
		else 
			System.out.println("INSERT FAIL");
		
	}
	

	public void getStudentList(HttpServletRequest request, HttpServletResponse response) {
		
		ArrayList<StudentVo> studentVos = studentDao.selectStudents();
		request.setAttribute("studentVos", studentVos);
		
	}
	

	public void modifyStudent(HttpServletRequest request, HttpServletResponse response) {
		
			int s_no = Integer.parseInt(request.getParameter("s_no"));
					
			StudentVo studentVo = studentDao.selectStudent(s_no);
			
			if (studentVo != null) {
				System.out.println("GETSTUDENT SUCCESS");
				request.setAttribute("studentVo", studentVo);
			} else {
				System.out.println("GETSTUDENT FAIL");
			}
		
	}
	

	public void modifyConfirm(HttpServletRequest request, HttpServletResponse response) {
		
		int s_no = Integer.parseInt(request.getParameter("s_no"));
		String s_name = request.getParameter("s_name");
		String s_gender = request.getParameter("s_gender");
		int s_grade = Integer.parseInt(request.getParameter("s_grade"));
		int s_number = Integer.parseInt(request.getParameter("s_number"));
		String s_major = request.getParameter("s_major");
		String s_phone = request.getParameter("s_phone");
		String s_mail = request.getParameter("s_mail");
		
		String s_absence = request.getParameter("s_absence");
		// String s_reg_date = request.getParameter("s_reg_date");
		String s_mod_date = request.getParameter("s_mod_date");
		
		String s_hobby = "";
		String[] s_hobbys = request.getParameterValues("s_hobby");
		
		for (int i = 0; i < s_hobbys.length; i++) {
			if (i != s_hobbys.length -1 ) {
			s_hobby += s_hobbys[i] + ','; 
			} else {
			s_hobby += s_hobbys[i];
			}
			
		
		StudentVo studentVo = new StudentVo(s_no, s_name, s_gender, s_grade, s_number, s_major, s_phone, s_mail, s_hobby, s_absence, s_mod_date);
				
		
		int result = studentDao.updateStudent(studentVo);
		
		if (result > 0) {
			System.out.println("UPDATE SUCCESS");
			request.setAttribute("studentVo", studentVo);
		} else { 
			System.out.println("UPDATE FAIL");
			
		}
		
	}

	public void deleteStudent(HttpServletRequest request, HttpServletResponse response) {
		
		
		int s_no = Integer.parseInt(request.getParameter("s_no"));
		
		int result = studentDao.deleteStudent(s_no);
		
		if (result > 0) {
			System.out.println("DELETE SUCCESS");
		} else { 
			System.out.println("DELETE FAIL");
			
		
		
	}

}
	
}
