package com.our.student.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.our.student.service.StudentService;

/**
 * Servlet implementation class StudentController
 */
@WebServlet("*.sm")
public class StudentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentController() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		
		StudentService studentService = null;
		String nextPage = null;
		
		if (command.equals("/register.sm")) {
			
			nextPage = "register.jsp";
			
		} else if (command.equals("/registerConfirm.sm")) {
			
			studentService = new StudentService();
			studentService.addStudent(request, response);
			nextPage = "/list.sm";
					
		} else if (command.equals("/list.sm")) {
			
			studentService = new StudentService();
			studentService.getStudentList(request, response);
			nextPage = "list.jsp"; 
		
		} else if (command.equals("/modify.sm")) {
			
			studentService = new StudentService();
			studentService.modifyStudent(request, response);
			nextPage = "modify.jsp";
					
		} else if (command.equals("/modifyConfirm.sm")) {
			
			studentService = new StudentService();
			studentService.modifyConfirm(request, response);
			nextPage = "/list.sm"; 
					
		} else if (command.equals("/delete.sm")) {
	
			studentService = new StudentService();
			studentService.deleteStudent(request, response);
			nextPage = "/list.sm";
		}
					
		
		
		
		
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(nextPage);
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		doGet(request, response);
	}

}
