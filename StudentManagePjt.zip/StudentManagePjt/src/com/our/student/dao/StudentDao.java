package com.our.student.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.our.student.vo.StudentVo;

public class StudentDao {
	

	 DataSource dataSource;
	
	public StudentDao() {
		
		try {
				
				Context context = new InitialContext();
				dataSource = (DataSource) context.lookup("java:comp/env/jdbc/mariadb");
				
			} catch (Exception e) {
				e.printStackTrace();
			}
	}

	public int insertStudent(StudentVo studentVo) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		
		try {


			conn = dataSource.getConnection();
			
			String sql = "INSERT INTO tbl_student_info(s_name, s_gender, s_grade, s_number, s_major, s_phone, s_mail, s_hobby, s_absence, s_reg_date, s_mod_date) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, studentVo.getS_name());
			pstmt.setString(2, studentVo.getS_gender());
			pstmt.setInt(3, studentVo.getS_grade());
			pstmt.setInt(4, studentVo.getS_number());
			pstmt.setString(5, studentVo.getS_major());
			pstmt.setString(6, studentVo.getS_phone());
			pstmt.setString(7, studentVo.getS_mail());
			pstmt.setString(8, studentVo.getS_hobby());
			pstmt.setString(9, studentVo.getS_absence());


			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {

				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();

			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return result;
	}

	
	
	
	
	public ArrayList<StudentVo> selectStudents() {
		
		Connection conn = null;
		PreparedStatement pstmt = null;   				
		ResultSet rs = null;     
		
		ArrayList<StudentVo> studentVos = new ArrayList<StudentVo>();
		
		try {
			
			conn = dataSource.getConnection();
			
			String sql = "SELECT * FROM tbl_student_info";
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
		
			
			while (rs.next()) {
				
				
				
				int s_no = rs.getInt("s_no");
				String s_name = rs.getString("s_name");
				String s_gender = rs.getString("s_gender");
				int s_grade = rs.getInt("s_grade");
				int s_number = rs.getInt("s_number");
				String s_major = rs.getString("s_major");
				String s_phone = rs.getString("s_phone");
				String s_mail = rs.getString("s_mail");
				String s_hobby = rs.getString("s_hobby");
				String s_absence = rs.getString("s_absence");
				String s_reg_date = rs.getString("s_reg_date");
				String s_mod_date = rs.getString("s_mod_date");
				
								
				
				StudentVo studentVo = new StudentVo(s_no, s_name, s_gender, s_grade, s_number, s_major, s_phone, s_mail, 
						s_hobby, s_absence, s_reg_date, s_mod_date);
				
				studentVos.add(studentVo);
				
				
				
			}
			
			} catch (Exception e) {
				e.printStackTrace();
				
			} finally {
				try {
					
					if (rs != null) rs.close();
					if (pstmt != null) pstmt.close();
					if (conn != null) conn.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
			
			
		return studentVos;
	}

	public StudentVo selectStudent(int sNo) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;   				
		ResultSet rs = null;     
		
		ArrayList<StudentVo> studentVos = new ArrayList<StudentVo>();
		
		try {
			
			conn = dataSource.getConnection();
			
			String sql = "SELECT * FROM tbl_student_info WHERE s_no =" + sNo;
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
		
			
			while (rs.next()) {
				
				
				
				int s_no = rs.getInt("s_no");
				String s_name = rs.getString("s_name");
				String s_gender = rs.getString("s_gender");
				int s_grade = rs.getInt("s_grade");
				int s_number = rs.getInt("s_number");
				String s_major = rs.getString("s_major");
				String s_phone = rs.getString("s_phone");
				String s_mail = rs.getString("s_mail");
				String s_hobby = rs.getString("s_hobby");
				String s_absence = rs.getString("s_absence");
				String s_reg_date = rs.getString("s_reg_date");
				String s_mod_date = rs.getString("s_mod_date");
				
								
				
				StudentVo studentVo = new StudentVo(s_no, s_name, s_gender, s_grade, s_number, s_major, s_phone, s_mail, 
						s_hobby, s_absence, s_reg_date, s_mod_date);
				
				studentVos.add(studentVo);
				
				
				
			}
			
			} catch (Exception e) {
				e.printStackTrace();
				
			} finally {
				try {
					
					if (rs != null) rs.close();
					if (pstmt != null) pstmt.close();
					if (conn != null) conn.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
			
			
		return studentVos.get(0) != null? studentVos.get(0): null;
	}

	public int updateStudent(StudentVo studentVo) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		
		try {

			conn = dataSource.getConnection();

			String sql = "UPDATE tbl_student_info SET "
					+ "s_name = ? ,"
					+ "s_gender = ?, "
					+ "s_grade = ?, "
					+ "s_number = ?, "
					+ "s_major = ?, "
					+ "s_phone = ?, "
					+ "s_mail = ?, "
					+ "s_hobby = ?, "
					+ "s_absence = ?, "
					+ "s_mod_date = ? "
					+ "WHERE s_no = ? ";
					
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, studentVo.getS_name());
			pstmt.setString(2, studentVo.getS_gender());
			pstmt.setInt(3, studentVo.getS_grade());
			pstmt.setInt(4, studentVo.getS_number());
			pstmt.setString(5, studentVo.getS_major());
			pstmt.setString(6, studentVo.getS_phone());
			pstmt.setString(7, studentVo.getS_mail());
			pstmt.setString(8, studentVo.getS_hobby());
			pstmt.setString(9, studentVo.getS_absence());
			pstmt.setString(10, studentVo.getS_mod_date());
			pstmt.setInt(11, studentVo.getS_no());
			
			
		

			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {

				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();

			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return result;
		
	}
	
	

	public int deleteStudent(int s_no) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		
		try {

			conn = dataSource.getConnection();

			String sql = "DELETE FROM tbl_student_info WHERE s_no = ? ";
					
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, s_no);
	
			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {

				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();

			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return result;
	}



}
